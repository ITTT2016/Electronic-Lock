#ifndef AKey
#define AKey
#include"Keypad.h"
#include"Password.h"
#include"LcdMenu.h"




#endif