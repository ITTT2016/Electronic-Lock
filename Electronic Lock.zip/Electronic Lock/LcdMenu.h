#ifndef LcdMenu
#define LcdMenu
//LCD module connections

sbit LCD_RS at RB4_bit;

sbit LCD_EN at RB5_bit;

sbit LCD_D4 at RB0_bit;

sbit LCD_D5 at RB1_bit;

sbit LCD_D6 at RB2_bit;

sbit LCD_D7 at RB3_bit;

sbit LCD_RS_Direction at TRISB4_bit;

sbit LCD_EN_Direction at TRISB5_bit;

sbit LCD_D4_Direction at TRISB0_bit;

sbit LCD_D5_Direction at TRISB1_bit;

sbit LCD_D6_Direction at TRISB2_bit;

sbit LCD_D7_Direction at TRISB3_bit;

//End LCD module connections

//Fonction de Comparaison
int cmp(char txt[5],char txt1[5])
{
 int i;
  for(i=1;i<6;i++)
{
 if(txt[i]!=txt1[i]) return 0;
}

return 1;

}

//affichage de la Marque
void Lcd_intro()
{

Lcd_Cmd(_LCD_CLEAR);
delay_ms(20);
Lcd_Out(1,4,"ITTT NewTech");
delay_ms(1000);

}

//affichage du Menu sur Lcd
void Lcd_Menu()
{

Lcd_Cmd(_LCD_CLEAR);
Lcd_Out(1,1,"1-CHANGE PASSWORD");
Lcd_Out(2,1,"2-KEYPAD 3-VOICE");

}

void Init()
{
Lcd_Init();
Lcd_Cmd(_LCD_CURSOR_OFF);
Lcd_Cmd(_LCD_CLEAR);

}

void write(int i,int i,char *txt)
{
   Init();
   Lcd_Out(i,i,txt);


}


#endif