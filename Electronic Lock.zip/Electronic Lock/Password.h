#ifndef Password
#define Password
#include"Keypad.h"
#include"LcdMenu.h"

char Pass[6];   //used to save the password
char txt[6],txt1[6]; //used to confirm the password
char A[6]; // used to check the password

//setting the password
void Set_password()
{

int i;

 do{
 write(1,1,"Set your Password");
 for(i=1;i<6;i++)
{
 Lire_Pad();
 Lcd_chr(2,i,Kp);
 txt[i]=Kp;
 delay_ms(2);
}

delay_ms(500);

write(1,1,"Repeat your Password");
for(i=1;i<6;i++)
{
 Lire_Pad();
 Lcd_chr(2,i,Kp);
 txt1[i]=Kp;
 delay_ms(2);
}

Init();

}while(!cmp(txt1,txt));

for(i=1;i<6;i++)
{
 Pass[i]=txt[i];
}
 txt[0]='\0';
 txt1[0]='\0';
 
 Init();
 
}

int check()
{
 int i;
 Lcd_Cmd(_LCD_SECOND_ROW);
 
for(i=1;i<6;i++)
{
 Lire_Pad();
 Lcd_chr_Cp(Kp);
 A[i]=Kp;
 delay_ms(2);
}
Init();

if(cmp(A,Pass)) return 1; else return 0;

}

void change()
{
  int N;
  
  write(1,1,"SET OLD PASSWORD");
  N=check();
  if(N){Set_password();}
   else {
        write(1,1,"WRONG PASSWORD!");
        delay_ms(2000);
        }

  Init();

}

void AccessP()
{
  int M;
  write(1,1,"SET YOUR PASSWORD");
  M=check();
  if(M){
  write(1,1,"VALID PASSWORD");
  delay_ms(2000);
  }
else {
  write(1,1,"WRONG PASSWORD!");
  delay_ms(2000);
  }


  Init();

}




#endif