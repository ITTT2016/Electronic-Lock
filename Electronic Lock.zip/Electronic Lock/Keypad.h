#ifndef Keypad
#define Keypad
//KeyPad module connections

char KeypadPort at PORTC;
unsigned short Kp;     //valeur lu par Pad

void Lire_Pad()
{
Kp='w';
do{
 Keypad_Init();
 Kp=Keypad_Key_Click();
 delay_ms(10);
 }
while(!Kp);
       //prepare value for output,transform key to it's ASCII value
 switch (Kp){
        case 1: Kp=49; break;    //1
        case 2: Kp=50; break;       //2
        case 3: Kp=51; break;      //3
        case 5: Kp=52; break;     //4
        case 6: Kp=53; break;     //5
        case 7: Kp=54; break;     //6
        case 9: Kp=55; break;     //7
        case 10:Kp=56; break;    //8
        case 11:Kp=57; break;    //9
        case 13:Kp=42; break;    //*
        case 14:Kp=48; break;    //0
        case 15:Kp=35; break;   //#
}

}




#endif