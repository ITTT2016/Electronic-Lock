#include"LcdMenu.h"
#include"Keypad.h"
#include"Password.h"



int g=1,H=0;

void main(){

  for(;;){

  Init();
  Lcd_intro();
  Init();
  if(g){Set_password(); g=0;}
  Init();
  Lcd_Menu();
  Lire_Pad();
  if(Kp=='1') change();

  


          }

}